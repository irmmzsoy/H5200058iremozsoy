package com.example.h5200058_remozsoyfinal.activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.h5200058_remozsoyfinal.util.GlideUtil;
import com.example.h5200058_remozsoyfinal.R;
import com.example.h5200058_remozsoyfinal.network.Service;
import com.example.h5200058_remozsoyfinal.model.Yazar;
import com.example.h5200058_remozsoyfinal.adaptor.YazarAdaptor;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity {


    ImageView imgKapak;
    String resimUrl = "https://static.birgun.net/resim/haber-detay-resim/2016/07/31/yazarlar-hakkinda-az-bilinenler-167466-5.jpg";

    RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();





    }

    private void init() {
        kapakResminiCek();
        yazarlariGetir();

    }

    private void kapakResminiCek()
    {
        imgKapak =findViewById( R.id.imgKapak);
        GlideUtil.resmiIndiripGoster(getApplicationContext(), resimUrl ,imgKapak );
    }

    private void initRecycleView(List<Yazar> yazarList)
    {
        recyclerView =findViewById(R.id.rcvYazarlar);

        YazarAdaptor yazarAdaptor =new YazarAdaptor(yazarList, getApplicationContext(), new YazarAdaptor.OnItemClickListener() {
                    @Override
                    public void onItemClick(Yazar tiklananYazar) {
                        Intent intent = new Intent(getApplicationContext(), DetayEkran.class);
                        intent.putExtra("isim", tiklananYazar.getIsim());
                        intent.putExtra("resimUrl", tiklananYazar.getResimUrl());
                        intent.putExtra("aciklama", tiklananYazar.getAciklama());
                        startActivity(intent);
                    }
                });


        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        recyclerView.setAdapter(yazarAdaptor);

    }


    void yazarlariGetir() {

        new Service().getServiceApi().yazarlariGetir().
                subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<List<Yazar>>() {
                    List<Yazar> yazarlar = new ArrayList<>();


                    @Override
                    public void onSubscribe(Disposable d) {
                    }


                    @Override
                    public void onNext(List<Yazar> yazarListParam) {
                        yazarlar = yazarListParam;
                    }


                    @Override
                    public void onError(Throwable e) {
                    }


                    @Override
                    public void onComplete() {

                        if (yazarlar.size() > 0) {
                            initRecycleView(yazarlar);
                        }


                    }


                });


    }


    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Çıkış")
                .setMessage("Uygulamadan çıkmak istediğinize emin misiniz?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton("Evet", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        MainActivity.super.onBackPressed();
                    }
                }).create().show();
    }


}


