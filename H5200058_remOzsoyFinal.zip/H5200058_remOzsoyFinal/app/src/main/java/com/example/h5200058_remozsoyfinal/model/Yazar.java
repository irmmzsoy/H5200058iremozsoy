package com.example.h5200058_remozsoyfinal.model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Yazar {

    @SerializedName("isim")
    @Expose
    private String isim;
    @SerializedName("tarih")
    @Expose
    private String tarih;
    @SerializedName("resimUrl")
    @Expose
    private String resimUrl;
    @SerializedName("aciklama")
    @Expose
    private String aciklama;


    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getTarih() {
        return tarih;
    }

    public void setTarih(String tarih) {
        this.tarih = tarih;
    }

    public String getResimUrl() {
        return resimUrl;
    }

    public void setResimUrl(String resimUrl) {
        this.resimUrl = resimUrl;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }

}