package com.example.h5200058_remozsoyfinal.activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.h5200058_remozsoyfinal.R;
import com.example.h5200058_remozsoyfinal.util.GlideUtil;

public class DetayEkran extends AppCompatActivity {

    ImageView imgKapak2;

    String resimUrl = "https://seyler.ekstat.com/img/max/800/t/txThu8Ll0DuJvCwT-636879225167961401.jpg";

    TextView adiYazar, aciklama;
    String htmlString ="<p>Stefan Zweig (28 Kasım 1881 - 22 Şubat 1942), Avusturyalı roman, oyun, biyografi yazarı ve gazetecidir. 1920'ler ile 1930'lar arasında edebiyat kariyerinin zirvesinde olmuş Zweig, dönemin dünyasının en çok tercüme edilen ve en popüler yazarlarından biriydi. 1920'li ve 1930'lu yıllarda Alman dilinin en çok okunan yazarları arasında sayılan Zweig'in eserleri, dünya çapında dönemin en çok okunan kitapları arasına girdi, elliyi aşkın dile tercüme edildi. 1933'te diğer Yahudi yazarlara da yapıldığı gibi eserleri, Naziler tarafından yakıldı. Bu olaydan sonra ülkesini terk eden Zweig, 1941'de Brezilya'ya yerleştikten sonra 22 Şubat 1942'de karısı Lotte Altmann ile birlikte intihar etti.</p>";





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detay_ekran);

        kapakResminiCek();


        adiYazar = findViewById(R.id.adiYazar);
        aciklama = findViewById(R.id.txtAciklama);

        adiYazar.setText("STEFAN ZWEIG"+ getIntent().getStringExtra("isim"));



        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N){
            aciklama.setText(Html.fromHtml(htmlString,Html.FROM_HTML_MODE_LEGACY));

        }
        else{
            aciklama.setText(Html.fromHtml(htmlString));
        }






    }



    private void kapakResminiCek()
    {
        imgKapak2 =findViewById( R.id.imgKapak2);
        GlideUtil.resmiIndiripGoster(getApplicationContext(), resimUrl ,imgKapak2 );
    }











}