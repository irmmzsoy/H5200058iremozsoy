package com.example.h5200058_remozsoyfinal.network;

import com.example.h5200058_remozsoyfinal.model.Yazar;

import java.util.List;

import io.reactivex.Observable;

import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface ServiceApi {

    @GET("Yazarlar.json")
    Observable<List<Yazar>> yazarlariGetir();


}



