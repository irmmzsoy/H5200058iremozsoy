package com.example.h5200058_remozsoyfinal.adaptor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.h5200058_remozsoyfinal.R;
import com.example.h5200058_remozsoyfinal.model.Yazar;
import com.example.h5200058_remozsoyfinal.util.GlideUtil;

import java.util.List;

public class YazarAdaptor extends RecyclerView.Adapter<YazarViewHolder> {


    List<Yazar> yazarlar;
    Context context;
    OnItemClickListener onItemClickListener;



    public interface OnItemClickListener {
        void onItemClick(Yazar tiklananYazar);
    }



    public YazarAdaptor (List <Yazar> yazarlar, Context context, OnItemClickListener onItemClickListener) {
        this.yazarlar = yazarlar;
        this.context = context;
        this.onItemClickListener =onItemClickListener;
    }


    @NonNull
    @Override
    public YazarViewHolder onCreateViewHolder (@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate( R.layout.list_item_yazar,parent, false);
        YazarViewHolder yazarViewHolder =new YazarViewHolder(itemView);

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onItemClick(yazarlar.get(yazarViewHolder.getAdapterPosition()));
            }
        });


        return yazarViewHolder;



    }


    @Override
    public void onBindViewHolder (@NonNull YazarViewHolder viewHolder, int position) {
        viewHolder. txtTarih.setText( yazarlar.get(position).getTarih());
        viewHolder. txtİsim.setText( yazarlar.get(position).getIsim());
        GlideUtil.resmiIndiripGoster(context,yazarlar.get(position).getResimUrl(),viewHolder. imgYazar);
    }



    @Override
    public int getItemCount () {
        return yazarlar.size();
    }
}

