package com.example.h5200058_remozsoyfinal;

import android.app.Application;

public class YazarlarApplication  extends Application {
}
