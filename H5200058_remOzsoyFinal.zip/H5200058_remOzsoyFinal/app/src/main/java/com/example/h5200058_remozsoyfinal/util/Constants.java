package com.example.h5200058_remozsoyfinal.util;

public class Constants {

    public static String BASE_URL = "https://raw.githubusercontent.com/irmmzsoy/H5200058iremozsoy/main/";






}
