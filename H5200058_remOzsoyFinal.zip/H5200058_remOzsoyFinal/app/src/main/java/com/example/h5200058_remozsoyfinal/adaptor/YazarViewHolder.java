package com.example.h5200058_remozsoyfinal.adaptor;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.h5200058_remozsoyfinal.R;

public class YazarViewHolder extends RecyclerView.ViewHolder {
    ImageView imgYazar;
    TextView txtİsim;
    TextView txtTarih;

    public YazarViewHolder (@NonNull View itemView) {
        super(itemView);
        imgYazar =itemView.findViewById( R.id.imgYazar);
        txtİsim =itemView.findViewById( R.id.txtİsim);
        txtTarih =itemView.findViewById( R.id.txtTarih);
    }
}
